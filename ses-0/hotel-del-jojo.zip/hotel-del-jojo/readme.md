# Hotel del Jojo
Selamat datang di _Hotel del Jojo_

Berikut adalah harga dari kamar-kamar yang kami punya: 
| | Tipe Kamar | Harga | 
|1| Pantai | ₩3,000,000 |
|2| Rooftop | ₩4,500,000 |
|3| Taman | ₩5,000,000 | 
|4| Bar | ₩1,250,000 |

**Selamat menginap!**